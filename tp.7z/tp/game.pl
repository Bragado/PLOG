:- use_module(library(lists)).

:- dynamic notPossibleMove/2.

jogada(Tab, Type, Player, NewTab, Cells) :-
	getMove(Type, Tab, Player, Line-Col),
	retract_move(Player),
	efetua_jogada(Tab, Player, Line-Col, Tab2),
	verifica_retirada(Tab2, Type, Player, Line-Col, NewTab, Cells).

getMove(pvp, Tab, Player, Line-Col)	:- pedeJogadaValida(Tab, Player, Line-Col).
getMove(ai, Tab, Player, Line-Col)	:- computeBestMove(Tab, Player, Line-Col).

verifica_retirada(Tab, Type, Player, Line-Col, NewTab, Cells) :-
	paths_affected(Tab, Player, Line-Col, Cells),
	analisaRetiradaOuter(Player, Line-Col, Cells, List),
	conclude(Tab, Type, Player, NewTab, List).

conclude(Tab, _, _, Tab, []).
conclude(Tab, Type, Player, NewTab, List) :-
	askPiece(Type, Player, List, Line-Col),
	retira_bola(Tab, Player, Line-Col, NewTab),
	assert(notPossibleMove(Player, Line-Col)).


retract_move(Player) :- retract(notPossibleMove(Player, _-_)).
retract_move(_).

askPiece(pvp, Player, List, Line-Col) :-
	nl, write('Choose one of your oponents piece to remove'), nl,
	printList(List), nl, nl,
	repeat,
		getLineNCol(LineAux-ColAux),
		player2(Player, P2),
		member(cell(Line-Col, P2), List),
	Line = LineAux, Col = ColAux.

askPiece(ai, List, Line-Col) :-
	computeRetirada(List, Line-Col).



getLineNCol(Line-Col) :-
	write('Insert a valid Line [character]:   '), read(LineAux), not(integer(LineAux)), letter(LineAux, Line), nl,
	write('Insert a valid Col [integer]:    '), read(Col), integer(Col),  nl.

pedeJogadaValida(Tab, Player, Line-Col) :-
	repeat,
		getLineNCol(LineAux-ColAux),
		lineNColRespectBoundries(Tab, LineAux-ColAux),
		not( notPossibleMove(Player, LineAux-ColAux)),
		testa_jogada(Tab, Player, LineAux-ColAux),
	Line = LineAux, Col = ColAux.

not(Goal) :- call(Goal),!,fail.
not(Goal).

retira_bola(Tab, Player, Line-Col, NewTab) :-
	setCellState(Tab, e, Line-Col, NewTab),
	player2(Player, P1),
	retract(balls(P1, Num)), Numb is Num +1,
	assert(balls(P1, Numb)).

lineNColRespectBoundries(Tab, Line-Col) :-
	Line > 0, Col > 0,
	total_height(Heigth), Line =< Heigth,
	width(Tab, Line, Width), Col =< Width.

width([], _, -1).
width([H|_], 1, Width) :-
	length(H, Width).
width([_|T], Line, Width) :- Line1 is Line - 1, width(T, Line1, Width).



jogo(Type) :-
	repeat,
		retract(state(Tab, Player)),
		jogada(Tab, Type, Player, NewTab, Cells),
		player2(Player, P1),
		assert(state(NewTab, P1)),
		testaFim(NewTab, Player, Cells),
	print_final(Player). %TODO

printList(List) :-
	length(List, Cols),
	firstPrint(Cols), nl,
	printCols(Cols), nl, write('|'),
	printLineAux(List, 0), nl,
	printFinalCols(0, Cols).


firstPrint(Cols) :- Cols > 0,
		    Total is 6*Cols - 1,
		    write(' '),
		    firstPrintAux(Total).
firstPrintAux(0).
firstPrintAux(Total) :-
	write('_'),
	Total1 is Total -1,
	firstPrintAux(Total1).
